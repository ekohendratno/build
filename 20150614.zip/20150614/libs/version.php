<?php 
/**
 * @fileName: version.php
 * @dir: libs/
 */
if(!defined('_iEXEC')) exit;

$version_system			= '3.00';//1.0.0-9.0.0

$version_project		= 'alpha'; //stable|beta|alpha

//$version_sba			= ''; //1-99

$version_build			= '20150614';

$version_php			= '5.4.16';

$version_mysql			= '5.0.10';

$api_url				= 'http://api.cmsid.org';

?>