<div id="content">
        <h2 class="pagetitle">Page Example</h2>
        <div class="clear"></div>
	  	<div class="entry">Ini halaman page-example.php
        </div>
</div> <!--end: content-->