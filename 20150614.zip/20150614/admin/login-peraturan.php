
        <div id="loginbox" style="margin-top:20px;" class="mainbox col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1">                      
            <div class="panel panel-default" >
                    <div class="panel-heading">
					<a href="login-register.php"><i class="glyphicon glyphicon-chevron-left"></i> Petunjuk penggunaan</a>
					</div>
                    <div class="panel-body" >
<fieldset>
    <legend>Aturan Umum dari portal</legend>
<ol>
<li>Portal kami dibuka untuk mengunjungi oleh semua orang tertarik. Untuk menggunakan semua ukuran jasa sebuah situs, perlu bagi Anda untuk mendaftar.</li>
<li>Pengguna portal bisa menjadi setiap orang, setuju untuk mematuhi aturan yang diberikan.</li>
<li>Setiap peserta dialog memiliki hak untuk kerahasiaan informasi. Oleh karena itu tidak membahas keuangan, keluarga dan kepentingan peserta lainnya tanpa izin di atasnya peserta.</li>
<li>Panggilan di situs terjadi pada &quot;Anda&quot;. Ini bukan tanda sopan atau ramah dalam kaitannya dengan teman bicara.</li>
<li>Portal kami - postmoderated. Informasi yang ditempatkan di situs, awal tidak dilihat dan tidak diedit, tetapi administrasi dan moderator berhak untuk dirinya sendiri agar nanti.</li>
<li>Semua pesan mencerminkan hanya pendapat penulisnya.</li>
<li>Urutan di portal ini diawasi oleh moderator. Mereka memiliki hak untuk mengedit, menghapus pesan dan untuk menutup mata pelajaran di bagian diperiksa oleh mereka.</li>
<li>Sebelum penciptaan subjek baru di forum, disarankan untuk mengambil keuntungan dari pencarian. Mungkin pertanyaan yang Anda ingin mengatur, sudah dibahas. Jika Anda memiliki troubleshot oleh kekuatan sendiri, silahkan, menulis tentang hal ini, dengan instruksi tentang bagaimana Anda membuatnya. Jika ingin menutup atau subject pesan, menginformasikan di atasnya untuk moderator.</li>
<li>Buat pelajaran baru hanya dalam bagian yang tepat. Jika subjek tidak mendekati di bawah salah satu bagian atau Anda meragukan kebenaran dari pilihan - menciptakannya dalam bagian dari sebuah forum &quot;papan Buletin&quot;.</li>
<li>Sebelum mengirim pesan atau menggunakan jasa portal, Anda diwajibkan untuk membiasakan dengan aturan umum, dan juga aturan departemen yang erat.</li>
<li>Dalam kasus pelanggaran kasar aturan, manajer berhak untuk dirinya sendiri untuk menghilangkan pengguna dari sebuah situs tanpa peringatan. Pendaftaran ulang dari pengguna dalam kasus menghapus dihilangkan.</li>
<li>Manajer berhak untuk dirinya sendiri untuk mengubah aturan yang diberikan tanpa pemberitahuan sebelumnya. Semua perubahan diberlakukan dari saat publikasi mereka.</li>
<li>Informasi dan link yang disajikan secara eksklusif dalam tujuan pendidikan dan ditujukan hanya untuk kepuasan rasa ingin tahu pengunjung.</li>
<li>Anda berjanji untuk tidak menerapkan informasi yang diterima dengan pemandangan, dilarang FC Federasi dan norma-norma hukum internasional Rusia.</li>
<li>Penulis situs yang diberikan tidak membawa tanggung jawab untuk konsekuensi dari penggunaan informasi dan link.</li>
<li>Jika Anda tidak setuju dengan persyaratan yang disebutkan di atas, dalam hal bahwa Anda harus meninggalkan situs kami segera.</li>
</ol><br>
<legend>Di situs itu dilarang</legend>
<ul>
<li>Untuk memecahkan subyek forum dan bagian.</li>
<li>Untuk membuat mata pelajaran yang baru-baru sudah dibahas dalam forum yang sama.</li>
<li>Untuk membuat subjek yang sama dalam beberapa bagian.</li>
<li>Untuk membuat subyek dengan nama kosong.</li>
<li>Untuk menggunakan tidak normatif leksikon, ekspresi kasar dalam kaitannya dengan teman bicara, menyinggung perasaan nasional atau keagamaan lawan bicara, dan juga untuk menulis huruf besar pesan.</li>
<li>Untuk menempatkan iklan. Iklan link ke situs dipromosikan, dengan alamat atau tanpa juga dianggap, atau homepage di tanda tangan.</li>
<li>Untuk mengekspos retak, nomor serial untuk program atau program yang telah retak. Juga dilarang untuk meninggalkan link ke mereka.</li>
<li>Untuk menulis pesan, yang tidak membawa informasi yang berguna (banjir, offtop) di bagian subjek.</li>
<li>Untuk mendiskusikan dan mengutuk operasi moderator dan administrasi, mungkin hanya dalam korespondensi pribadi atau keluhan, administrasi diarahkan dari portal.</li>
</ul>
</fieldset>

                    </div>                     
            </div>  
        </div>
		 
