<?php 
/**
 * @fileName: login.php
 * @dir: admin/
 */
if(!defined('_iEXEC')) exit;
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title><?php the_login_title()?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="libs/css/bootstrap.css" rel="stylesheet" id="bootstrap-css">
    <script src="libs/js/jquery-1.10.2.js"></script>
    <script src="libs/js/bootstrap.min.js"></script>
	<?php the_head_login()?>
</head>
<body>   

<div class="container">   

<?php 

$login_file = 'main.php';

if( $login = get_query_var('login') && is_login() ){
	if( file_exists($login.'.php') )
	$login_file = $login.'.php';
}

require_once admin_path.'/login-'.$login_file;

?>
</div>
    
</body>
</html>
