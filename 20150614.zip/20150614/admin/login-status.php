
        <div id="loginbox" style="margin-top:20px;" class="mainbox col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3">                    
            <div class="panel panel-default" >
                    <div class="panel-heading">
					<a href="login-profile.php"><i class="glyphicon glyphicon-chevron-left"></i> Status</a>
					<div class="pull-right"> 
						<a href="dashboard.html" class="pull-right"><i class="glyphicon glyphicon-th-list"></i> Manage Dashboard</a> 
					</div>
					</div>
                    <div class="panel-body" >

                        <div style="display:none" id="login-alert" class="alert alert-danger col-sm-12"></div>
                            
                        <form id="loginform" class="form-horizontal" role="form" action="login.php" method="post">
                                    
							<center>
							<img src="img/cinqueterre.jpg" class="img-circle" alt="Cinque Terre" height="100" width="100" style="margin-bottom:20px;" >
                            <h4>Eko Azza</h4>
							<p class="text-muted">@ekoazza<br>Login Date/Time: 23 Oktober 2015</p>
							<button id="btn-login" class="btn btn-primary btn-danger btn-lg btn-block" type="submit">Logout</button>
							
							</center>
							</div>
                        </form>   



                    </div>                     
            </div>  
        </div>
		 
